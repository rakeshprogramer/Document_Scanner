// Add interactivity later
console.log("Frontend loaded");