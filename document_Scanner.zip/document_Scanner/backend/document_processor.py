import os
from credit_system import can_scan, deduct_credit
from database import add_document, get_all_documents

STORAGE_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "storage", "documents")

def upload_document(user_id, file):
    if not can_scan(user_id):
        return False, "Insufficient credits or user not found", None
    if not file or file.filename == "":
        return False, "No file uploaded", None
    if not file.filename.endswith(".txt"):
        return False, "Only .txt files are supported", None

    filename = f"{user_id}_{os.path.basename(file.filename)}"
    file_path = os.path.join(STORAGE_PATH, filename)
    file.save(file_path)

    success, message = deduct_credit(user_id)
    if not success:
        os.remove(file_path)
        return False, message, None

    doc_id = add_document(user_id, filename)
    return True, "Document uploaded and scanned", doc_id

def get_document_content(doc_id):
    doc = get_all_documents()
    for d in doc:
        if d[0] == doc_id:
            file_path = os.path.join(STORAGE_PATH, d[2])
            if os.path.exists(file_path):
                with open(file_path, "r", encoding="utf-8") as f:
                    return f.read()
    return None

def calculate_similarity(text1, text2):
    words1 = set(text1.lower().split())
    words2 = set(text2.lower().split())
    common_words = words1.intersection(words2)
    total_words = words1.union(words2)
    if not total_words:
        return 0.0
    return len(common_words) / len(total_words) * 100

def find_matches(doc_id):
    target_content = get_document_content(doc_id)
    if not target_content:
        return []

    all_docs = get_all_documents()
    matches = []
    for doc in all_docs:
        if doc[0] == doc_id:
            continue
        file_path = os.path.join(STORAGE_PATH, doc[2])
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            similarity = calculate_similarity(target_content, content)
            if similarity > 20:
                matches.append({"doc_id": doc[0], "filename": doc[2], "similarity": similarity})
    return sorted(matches, key=lambda x: x["similarity"], reverse=True)

def get_common_topics():
    all_docs = get_all_documents()
    word_freq = {}
    for doc in all_docs:
        file_path = os.path.join(STORAGE_PATH, doc[2])
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                words = f.read().lower().split()
                for word in words:
                    if len(word) > 3:  # Ignore short words
                        word_freq[word] = word_freq.get(word, 0) + 1
    return sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:10]