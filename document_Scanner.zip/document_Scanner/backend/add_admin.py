import hashlib
from database import add_user

password = "admin1234"
hashed_password = hashlib.sha256(password.encode()).hexdigest()

add_user("admin1", hashed_password, "admin11")
print("Admin user added successfully!")