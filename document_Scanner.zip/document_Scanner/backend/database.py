import sqlite3
import os
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "db", "scanner.db")

def init_db():
    if not os.path.exists(os.path.dirname(DB_PATH)):
        os.makedirs(os.path.dirname(DB_PATH))
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            credits INTEGER DEFAULT 20,
            last_reset TEXT DEFAULT (datetime('now', 'localtime'))
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            filename TEXT NOT NULL,
            upload_date TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS credit_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            requested_credits INTEGER,
            status TEXT DEFAULT 'pending',
            request_date TEXT DEFAULT (datetime('now', 'localtime')),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    conn.commit()
    conn.close()

def add_user(username, password, role="user"):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO users (username, password, role, credits, last_reset) VALUES (?, ?, ?, 20, ?)",
              (username, password, role, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def get_user(username):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?", (username,))
    user = c.fetchone()
    conn.close()
    return user

def get_user_by_id(user_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user = c.fetchone()
    conn.close()
    return user

def update_credits(user_id, credits):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE users SET credits = ? WHERE id = ?", (credits, user_id))
    conn.commit()
    conn.close()

def reset_credits(user_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE users SET credits = 20, last_reset = ? WHERE id = ?",
              (datetime.now().isoformat(), user_id))
    conn.commit()
    conn.close()

def request_credits(user_id, amount):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO credit_requests (user_id, requested_credits, request_date) VALUES (?, ?, ?)",
              (user_id, amount, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def get_pending_requests():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT cr.id, u.username, cr.requested_credits, cr.request_date "
              "FROM credit_requests cr JOIN users u ON cr.user_id = u.id WHERE cr.status = 'pending'")
    requests = c.fetchall()
    conn.close()
    return requests

def update_request_status(request_id, status, user_id, requested_credits):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE credit_requests SET status = ? WHERE id = ?", (status, request_id))
    if status == "approved":
        c.execute("UPDATE users SET credits = credits + ? WHERE id = ?", (requested_credits, user_id))
    conn.commit()
    conn.close()

def add_document(user_id, filename):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO documents (user_id, filename, upload_date) VALUES (?, ?, ?)",
              (user_id, filename, datetime.now().isoformat()))
    conn.commit()
    doc_id = c.lastrowid
    conn.close()
    return doc_id

def get_document(doc_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM documents WHERE id = ?", (doc_id,))
    doc = c.fetchone()
    conn.close()
    return doc

def get_all_documents():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id, user_id, filename, upload_date FROM documents")
    docs = c.fetchall()
    conn.close()
    return docs

def get_scans_per_user_per_day():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT u.username, DATE(d.upload_date), COUNT(*) as scan_count
        FROM documents d
        JOIN users u ON d.user_id = u.id
        GROUP BY u.username, DATE(d.upload_date)
        ORDER BY DATE(d.upload_date) DESC
    """)
    result = c.fetchall()
    conn.close()
    return result

def get_top_users_by_scans(limit=5):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT u.username, COUNT(d.id) as scan_count
        FROM users u
        LEFT JOIN documents d ON u.id = d.user_id
        GROUP BY u.id, u.username
        ORDER BY scan_count DESC
        LIMIT ?
    """, (limit,))
    result = c.fetchall()
    conn.close()
    return result

def get_credit_usage_stats():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT u.username, SUM(CASE WHEN cr.status = 'approved' THEN cr.requested_credits ELSE 0 END) as approved_credits,
               COUNT(CASE WHEN cr.status = 'pending' THEN 1 END) as pending_requests
        FROM users u
        LEFT JOIN credit_requests cr ON u.id = cr.user_id
        GROUP BY u.id, u.username
    """)
    result = c.fetchall()
    conn.close()
    return result

def get_user_documents(user_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id, filename, upload_date FROM documents WHERE user_id = ? ORDER BY upload_date DESC", (user_id,))
    docs = c.fetchall()
    conn.close()
    return docs

def delete_document(doc_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DELETE FROM documents WHERE id = ?", (doc_id,))
    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()