from datetime import datetime
from database import get_user_by_id, reset_credits, update_credits

def check_and_reset_credits(user_id):
    user = get_user_by_id(user_id)
    if not user or len(user) < 6:
        return False
    last_reset = datetime.fromisoformat(user[5])
    now = datetime.now()
    if (now - last_reset).days >= 1:
        reset_credits(user_id)
        return True
    return False

def deduct_credit(user_id):
    user = get_user_by_id(user_id)
    if not user or len(user) < 5 or user[4] <= 0:
        return False, "Insufficient credits"
    update_credits(user_id, user[4] - 1)
    return True, "Credit deducted"

def can_scan(user_id):
    check_and_reset_credits(user_id)
    user = get_user_by_id(user_id)
    return user and len(user) >= 5 and user[4] > 0