from flask import Flask, render_template, request, jsonify, session, redirect, url_for, send_file
import os
from auth import register_user, login_user, is_logged_in, logout_user, get_current_user, is_admin
from credit_system import check_and_reset_credits, deduct_credit, can_scan
from database import (request_credits, get_pending_requests, update_request_status, get_user,
                     get_scans_per_user_per_day, get_top_users_by_scans, get_credit_usage_stats, get_user_documents,
                     get_document, delete_document)
from document_processor import upload_document, find_matches, get_common_topics


app = Flask(__name__, template_folder="../frontend", static_folder="../frontend")
app = Flask(__name__,
            template_folder="C:/Users/rakes/OneDrive/Desktop/document_Scanner/frontend",
            static_folder="C:/Users/rakes/OneDrive/Desktop/document_Scanner/frontend",
            )
app.secret_key = "dsakhasklfhkhsadkjhsdhfjhsdkfhksj"

if not os.path.exists("storage/documents"):
    os.makedirs("storage/documents")

print(f"Template folder set to: {os.path.abspath(app.template_folder)}")
print(f"Static folder set to: {os.path.abspath(app.static_folder)}")

@app.route("/")
def home():
    print("Handling request for /")
    if is_logged_in():
        print("User logged in, redirecting to /profile")
        return redirect(url_for("profile"))
    template_path = os.path.join(app.template_folder, "index.html")
    print(f"Looking for template at: {template_path}")
    if not os.path.exists(template_path):
        print(f"Template not found at: {template_path}")
        return "Template not found", 404
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        success, message = register_user(username, password)
        if success:
            return redirect(url_for("login"))
        return render_template("register.html", error=message)
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        success, message = login_user(username, password)
        if success:
            return redirect(url_for("profile"))
        return render_template("login.html", error=message)
    return render_template("login.html")

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("home"))

@app.route("/profile", methods=["GET", "POST"])
def profile():
    if not is_logged_in():
        print("Redirecting to login: Not logged in")
        return redirect(url_for("login"))
    user = get_current_user()
    if user is None:
        print("User is None, logging out")
        logout_user()
        return redirect(url_for("login"))
    check_and_reset_credits(user[0])
    user = get_current_user()
    if request.method == "POST":
        try:
            amount = int(request.form["credits"])
            request_credits(user[0], amount)
            return render_template("profile.html", user={
                "username": user[1], "role": user[3], "credits": user[4]
            }, message="Credit request submitted", documents=get_user_documents(user[0]))
        except ValueError:
            return render_template("profile.html", user={
                "username": user[1], "role": user[3], "credits": user[4]
            }, error="Invalid credit amount", documents=get_user_documents(user[0]))
    return render_template("profile.html", user={
        "username": user[1], "role": user[3], "credits": user[4]
    }, documents=get_user_documents(user[0]))

@app.route("/admin/credits", methods=["GET", "POST"])
def admin_credits():
    if not is_admin():
        return redirect(url_for("login"))
    if request.method == "POST":
        try:
            request_id = int(request.form["request_id"])
            action = request.form["action"]
            print(f"Processing request_id={request_id}, action={action}")
            req = next((r for r in get_pending_requests() if r[0] == request_id), None)
            if req:
                print(f"Found request: {req}")
                user_id = get_user(req[1])[0]
                update_request_status(request_id, action, user_id, req[2])
                print(f"Updated request_id={request_id} to {action}")
            else:
                print(f"No request found for request_id={request_id}")
                return render_template("admin_credits.html", requests=get_pending_requests(), error="Request not found")
        except Exception as e:
            print(f"Error in admin_credits: {str(e)}")
            return render_template("admin_credits.html", requests=get_pending_requests(), error=str(e))
    requests = get_pending_requests()
    return render_template("admin_credits.html", requests=requests)

@app.route("/analytics")
def analytics():
    if not is_logged_in():
        return redirect(url_for("login"))
    scans_per_day = get_scans_per_user_per_day()
    topics = get_common_topics()
    top_users = get_top_users_by_scans()
    credit_stats = get_credit_usage_stats()
    return render_template("analytics.html", scans_per_day=scans_per_day, topics=topics,
                           top_users=top_users, credit_stats=credit_stats)

@app.route("/scan", methods=["GET", "POST"])
def scan():
    if not is_logged_in():
        return redirect(url_for("login"))
    user = get_current_user()
    if user is None:
        logout_user()
        return redirect(url_for("login"))
    if request.method == "POST":
        file = request.files.get("document")
        success, message, doc_id = upload_document(user[0], file)
        if success:
            return render_template("upload.html", message=message, doc_id=doc_id)
        return render_template("upload.html", error=message)
    return render_template("upload.html")

@app.route("/matches/<int:doc_id>")
def matches(doc_id):
    if not is_logged_in():
        return redirect(url_for("login"))
    matches = find_matches(doc_id)
    return render_template("matches.html", matches=matches, doc_id=doc_id)

@app.route("/documents/delete/<int:doc_id>")
def delete_document_route(doc_id):
    if not is_logged_in():
        return redirect(url_for("login"))
    user = get_current_user()
    if user is None:
        logout_user()
        return redirect(url_for("login"))
    # Fetch document to verify ownership
    doc = get_document(doc_id)
    if doc is None or doc[1] != user[0]:  # doc[1] is user_id
        return redirect(url_for("profile"))
    # Delete the document file and database entry
    file_path = os.path.join("storage/documents", doc[2])  # doc[2] is filename
    if os.path.exists(file_path):
        os.remove(file_path)
    delete_document(doc_id)
    return redirect(url_for("profile"))

@app.route("/documents/download/<int:doc_id>")
def download_document(doc_id):
    if not is_logged_in():
        return redirect(url_for("login"))
    user = get_current_user()
    if user is None:
        logout_user()
        return redirect(url_for("login"))
    # Fetch document to verify ownership
    doc = get_document(doc_id)
    if doc is None or doc[1] != user[0]:  # doc[1] is user_id
        return redirect(url_for("profile"))
    # Send the file for download
    file_path = os.path.join("storage/documents", doc[2])  # doc[2] is filename
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    return redirect(url_for("profile"))

@app.route("/auth/register", methods=["POST"])
def api_register():
    data = request.json
    if not data or "username" not in data or "password" not in data:
        return jsonify({"success": False, "message": "Missing username or password"}), 400
    success, message = register_user(data["username"], data["password"])
    return jsonify({"success": success, "message": message})

@app.route("/auth/login", methods=["POST"])
def api_login():
    data = request.json
    if not data or "username" not in data or "password" not in data:
        return jsonify({"success": False, "message": "Missing username or password"}), 400
    success, message = login_user(data["username"], data["password"])
    return jsonify({"success": success, "message": message})

@app.route("/user/profile", methods=["GET"])
def api_profile():
    if not is_logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    user = get_current_user()
    if user is None:
        logout_user()
        return jsonify({"error": "Session invalid"}), 401
    return jsonify({"username": user[1], "role": user[3], "credits": user[4]})

@app.route("/credits/request", methods=["POST"])
def api_request_credits():
    if not is_logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    data = request.json
    if not data or "credits" not in data:
        return jsonify({"success": False, "message": "Missing credits field"}), 400
    try:
        amount = int(data["credits"])
        request_credits(session["user_id"], amount)
        return jsonify({"success": True, "message": "Credit request submitted"})
    except ValueError:
        return jsonify({"success": False, "message": "Invalid credit amount"}), 400

@app.route("/scan", methods=["POST"])
def api_scan():
    if not is_logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    user = get_current_user()
    if user is None:
        logout_user()
        return jsonify({"error": "Session invalid"}), 401
    file = request.files.get("document")
    success, message, doc_id = upload_document(user[0], file)
    if success:
        return jsonify({"success": True, "message": message, "doc_id": doc_id})
    return jsonify({"success": False, "message": message}), 400

@app.route("/matches/<int:doc_id>", methods=["GET"])
def api_matches(doc_id):
    if not is_logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    matches = find_matches(doc_id)
    return jsonify({"matches": matches})

@app.route("/analytics", methods=["GET"])
def api_analytics():
    if not is_logged_in():
        return jsonify({"error": "Unauthorized"}), 401
    scans_per_day = get_scans_per_user_per_day()
    topics = get_common_topics()
    top_users = get_top_users_by_scans()
    credit_stats = get_credit_usage_stats()
    return jsonify({
        "scans_per_day": [{"username": s[0], "date": s[1], "scan_count": s[2]} for s in scans_per_day],
        "topics": [{"word": t[0], "frequency": t[1]} for t in topics],
        "top_users": [{"username": u[0], "scan_count": u[1]} for u in top_users],
        "credit_stats": [{"username": c[0], "approved_credits": c[1] or 0, "pending_requests": c[2] or 0} for c in credit_stats]
    })

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)