from flask import session
import hashlib

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def register_user(username, password, role="user"):
    from database import get_user, add_user
    if get_user(username):
        return False, "Username already exists"
    hashed_password = hash_password(password)
    add_user(username, hashed_password, role)
    return True, "Registration successful"

def login_user(username, password):
    from database import get_user
    user = get_user(username)
    if user and user[2] == hash_password(password):
        session["user_id"] = user[0]
        session["username"] = user[1]
        session["role"] = user[3]
        print(f"Login successful: session={session}")
        return True, "Login successful"
    print(f"Login failed: user={user}, password_match={user and user[2] == hash_password(password)}")
    return False, "Invalid credentials"

def is_logged_in():
    logged_in = "user_id" in session
    print(f"is_logged_in: {logged_in}, session={session}")
    return logged_in

def is_admin():
    return is_logged_in() and session.get("role") == "admin"

def get_current_user():
    from database import get_user_by_id
    if is_logged_in():
        user = get_user_by_id(session["user_id"])
        print(f"get_current_user: user_id={session['user_id']}, user={user}")
        return user
    return None

def logout_user():
    session.clear()
    
    
#app = Flask(__name__, template_folder="../frontend", static_folder="../frontend")
#app.secret_key = "your-secret-key"